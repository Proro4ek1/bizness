$( function() {
    $( "#map" ).draggable();
} );
